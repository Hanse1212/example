var express = require('express');
var socket = require('socket.io');

var app = express();

app.use(express.static('public'));



var server  = app.listen(8081, ()=>{
    console.log('작동 중 포트번호 : 8081');
});


var io = socket(server);

io.on('connection', (socket)=>{
    console.log('socket이 연결되었습니다.');
    socket.on('chat', (data)=>{
        io.sockets.emit('chat', data);
    });
    socket.on('typing', (data)=>{
        socket.broadcast.emit('typing', data)
    });

});