var socket = io.connect('http://localhost:8081');

var message = document.getElementById('message');
var handle = document.getElementById('handle');
var btn = document.getElementById('send');
var output = document.getElementById('output');
var feedback = document.getElementById('feedback');

btn.addEventListener('click', ()=>{
    socket.emit('chat', {
        message : message.value,
        handle : handle.value
    });
});
message.addEventListener('keypress', ()=>{
    socket.emit('typing', handle.value)
});

//이벤트가 발생하고 나면
socket.on('chat', (data)=>{
    feedback.innerHTML="";
    output.innerHTML += `<p><strong>${data.handle}</strong>${data.message}</p>`;
});
socket.on('typing', (data)=>{
    feedback.innerHTML=`<p><em>${data} is typing...</em></p>`;
})





// 클라이언트 ---> 서버로 내요을 전송할 때
// socket.io의 emit으로 송신한 정보를 on으로 받는다
// connection 은 socket.io의 기본 이벤트로 웹사이트에 접속하면 자동으로 발생하는 이벤트이다.

// 서버--->클라이언트로 내요을 전송할 때
// socket.emit은 서버 쪽에서 발생하는 함수로  서버에서 발생시키면 클라이언트 페이지 네의 이벤트 리스너에서 처리한다.
// 형식은 socket.emit('이벤트 이름', 메시지)

// 이벤트의 이름은 서버와 클라이언트에서 통일한다.