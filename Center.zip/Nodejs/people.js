const people = ['철수', '영희', '유리', '훈이'];
const age = ['10', '20', '30', '40'];
// console.log(people);
module.exports = {
    people:people,
    age:age
}