const name = ['짱구', '철수', '맹구', '유리', '훈이'];
module.exports = {
    name:name
}