// const http = require('http');
const express = require('express')
const app = express()
app.listen(3000)
app.set('view engine', 'ejs')
// app.get('/', (req, res)=>{
//     res.setHeader('Content-Type', 'text/html', 'utf-8')
//     res.write('ok')
//     res.end()
// })
// app.get('/about', (req, res)=>{
//     res.setHeader('Content-Type', 'text/html', 'utf-8')
//     res.write('<h2>about</h2>')
//     res.end()
// })

app.get('/', (req, res)=>{
    res.render('index', {title: '심플한 index'});
})

// app.get('/', (req, res)=>{
//     res.sendFile('./view/index.html', {root: __dirname})
// })
app.get('/about', (req, res)=>{
    res.render('about', {title: '심플한 about'})
})
app.get('/about-us', (req, res)=>{
    res.render('/about')
})
app.use((req, res)=>{
    res.render('404', {title: '심플한 404'})
})

