const fs = require('fs');
// fs.readFile('./assets/blogs.txt','utf-8', (err, data)=>{
//     if(err){
//         console.log(err);
//     } else {
//         console.log(data,toString());
//     }
// });
// fs.writeFile('./assets/blog2.txt','서버구성을 위한 기본',()=>{
//     console.log('완료됨');
// });
// if(!fs.existsSync('./assets')){
//     fs.mkdir('./assets',(err)=>{
//         if(err){
//             console.log(err);
//         } else {
//             console.log('생성완료');
//         }
//     })
// } else {
//     fs.rmdir('./assets', (err)=>{
//         if(err){
//             console.log(err);
//         } else {
//             console.log('삭제 완료');
//         }
//     })
// }
if(fs.existsSync('./assets/blogs.txt')){
    fs.unlink('./assets/blogs.txt', (err)=>{
        if(err){
            console.log(err);
        } else {
            console.log('파일 삭제');
        }
    })
}