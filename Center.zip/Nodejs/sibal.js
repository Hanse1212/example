const url = require('url');
// const urlobj = url.parse("http://localhost:3000/path/abc.html?id=student&page=12#hash", true);
const urlobj = url.parse("http://localhost:3000/path/abc.html?id=student&page=12#hash", false);
console.log(urlobj);

// const myUrl = new URL("http://example.com/about#bar");
// console.log(myUrl.hash);
// console.log(myUrl.host);
// console.log(myUrl.hostname);
// console.log(myUrl.href);

// const myUrl = new URL("http://example:xyz@gmail.com");
// console.log(myUrl.password);
// myUrl.password = '123';
// console.log(myUrl.href);

// const myUrl = new URL("http://example.com/abc/xyz?123");
// console.log(myUrl.pathname);
// myUrl.pathname='/abcdef';
// console.log(myUrl.href);

// const myUrl = new URL("http://example:xyz@gmail.com");
// console.log(myUrl.username);