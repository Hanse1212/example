const http = require('http');
http.createServer(function(req,res){
    res.setHeader('Content-Type','text/plain');
    // res.setHeader('Content-Type','text/html');
    // res.write('<h1>hello</h1>');
    res.write('plain');
    res.end();
}).listen(3000);