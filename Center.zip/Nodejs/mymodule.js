// const people = require('./people');
// const abc = require('./people');
// console.log('age : ', abc.age);
// console.log('people : ', abc.people);
