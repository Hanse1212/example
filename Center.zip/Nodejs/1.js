// var name = '홍길동';
// console.log(`${name}`);

// setTimeout(()=>{
//     console.log('asdasd');
//     clearInterval(example);
// }, 3000)

// const example = setInterval(()=>{
//     console.log('asdasd');
// }, 1000)

// console.log('__dirname : ' + __dirname);
// console.log('__filename : ' + __filename);

const os = require('os');
console.log(os.platform());
console.log(os.homedir());