const abc = require('./a.js');
console.log(abc.name);