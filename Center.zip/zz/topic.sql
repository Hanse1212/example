create table topic(
id numeric primary key,
title varchar(30) not null,
des varchar(50) not null,
date date not null,
author varchar(50) not null,
profile varchar(30) not null
);