const express = require('express');
const app = express();


var db_config = require(__dirname+'/database.js');
var conn = db_config.init();
db_config.connect(conn);




app.listen(3000,'localhost',()=>{
    console.log('Server is on');
});
app.set('view engine','ejs');
app.use(express.static('public'))

app.get('/', (req,res)=>{
    res.render('index',{title: '심플한 index'})
});
app.get('/about', (req,res)=>{
    res.render('about',{title: '심플한 about'})
});
app.get('/list', function(req,res){
    var sql = 'select * from topic';
    conn.query(sql, function(err, rows, fields){
        if(err){
            console.log('쿼리 실행 x', err);
        } else {
            res.render('list',{title: '심플한 list',list: rows})
        }
    })
});
app.get('/profile', (req,res)=>{
    res.render('profile',{title: '심플한 profile'})
});
app.use((req,res)=>{
    res.status(404).render('404',{title: '심플한 error'})
});