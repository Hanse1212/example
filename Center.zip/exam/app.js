const express = require('express');
const morgan = require('morgan');
const app = express();
app.listen(3000);

app.use(morgan('dev'))
app.set('view engine','ejs')
// app.get((req,res)=>{
//     const blogs =[
//         {title: 'AAA', sms: '1 asdasdasdasdasdasdasdasd'},
//         {title: 'BBB', sms: '2 asdasdasdasdasdasdasdasd'},
//         {title: 'CCC', sms: '3 asdasdasdasdasdasdasdasd'}
//     ]
//     res.render('index', {blogs:blogs});
// })
app.use(express.static('public'))

app.get('/', (req, res)=>{
    res.render('index', {title: '심플한 index'});
})

app.get('/about', (req, res)=>{
    res.render('about', {title: '심플한 about'})
})
app.get('/about-us', (req, res)=>{
    res.render('/about')
})
app.use((req, res)=>{
    res.render('404', {title: '심플한 404'})
})