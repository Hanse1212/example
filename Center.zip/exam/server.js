const http = require('http');
const fs = require('fs');
const url = require('url');

const server = http.createServer((req,res)=>{
    res.setHeader('Content-Type','text/html','utf-8')
    let path = './view';
    switch(res.url){
        case '/':
            res.statusCode=200;
            path += 'index.html';
            break;
        case '/about':
            res.statusCode=200;
            path += 'about.html';
            break;
        case '/about-us':
            res.statusCode=301;
            res.setHeader('location','/about')
            res.end()
            break;
        default:
            res.statusCode=404;
            path += '404.html';
            break;
    }
})

fs.readFile(path, (err, data)=>{
    if(err){
        console.log(err)
        res.end()
    } else {
        res.end(data)
    }
})

server.listen(3000, 'localhost', ()=>{
    console.log('서버 작동')
})