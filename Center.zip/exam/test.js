const express = require('express');
const morgan = require('morgan');
const app = express();
app.listen(3000);

app.use(morgan('dev'));
app.set('view engine','ejs');
app.use((req,res,next)=>{
    console.log('new req');
    console.log('host',req.hostname);
    console.log('path',req.path);
    next();
})
app.use((req,res)=>{
    console.log('-----again-----')
    console.log('host',req.hostname)
    console.log('path',req.path)
})

app.get('/', (req, res)=>{
    res.render('index', {title: '심플한 index'});
})

app.get('/about', (req, res)=>{
    res.render('about', {title: '심플한 about'})
})
app.get('/about-us', (req, res)=>{
    res.render('/about')
})
app.use((req, res)=>{
    res.render('404', {title: '심플한 404'})
})