// var button = document.getElementById('btn');
// button.addEventListener();

// function runEvent(e) {
//     console.log('EVENT TYPE : ' + e.type);
//     document.getElementById('output').innerHTML="<h3> MouseX : " + e.offsetX + "</h3><h3> MouseY" + e.offsetY + "</h3>";
//     box.style.backgroundColor="red";
// }

// var box = document.getElementById('box');
// box.addEventListener('mouseenter', runEvent);

// var dropdown = document.querySelector('select');
// dropdown.addEventListener('change', runEvent);
// dropdown.addEventListener('input', runEvent);

// function runEvent(e){
//     alert('Event type : ' + e.type);
// }

// var itemInput = document.querySelector('input[type="text"]');
// itemInput.addEventListener('keydown', runEvent);
// itemInput.addEventListener('keyup', runEvent);
// itemInput.addEventListener('keypress', runEvent);

// itemInput.addEventListener('focus', runEvent);
// itemInput.addEventListener('blur', runEvent);

// itemInput.addEventListener('cut', runEvent);
// itemInput.addEventListener('paste', runEvent);
// itemInput.addEventListener('copy', runEvent);

// var from = document.querySelector('form');
// from.addEventListener('submit', runEvent);

// function runEvent(e){
//     e.preventDefault();
//     alert('Event type : ' + e.type);
// }