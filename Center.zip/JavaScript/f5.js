// const from = document.getElementById('');
const itemList = document.getElementById('items');
const filter = document.getElementById('filter');

function addItem(e){
    e.preventDefault();
}