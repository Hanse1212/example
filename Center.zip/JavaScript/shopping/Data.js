let shopItemData=[
    {
        id:"m_office",
        name : "ASDFASDF",
        img : "./image-1.jpg",
        price : 45,
        desc : "flued hem dreoss"
    },
        {
            id:"m_shirt",
            name : "ASDFASDF",
            img : "./image-2.jpg",
            price : 50,
            desc : "flued hem dreoss"
        },
        {
            id:"m_suit",
            name : "ASDFASDF",
            img : "./image-3.jpg",
            price : 55,
            desc : "flued hem dreoss"
        },
        {
        id:"m_tshirt",
        name : "ASzASDF",
        img : "./image-4.jpg",
        price : 60,
        desc : "flued hem dreoss"
        }
];