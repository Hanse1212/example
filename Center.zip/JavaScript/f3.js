document.getElementById('btn').addEventListener('click', buttonClick);
// 함수가 인수로 들어갈 경우에 () 는 생략
// 함수가 나타날떄는 () 필수
function buttonClick(e){
    console.log('e.target : ', e.target);
    console.log('e.target.className : ', e.target.className);
    console.log('e.target.classList : ', e.target.classList);
    var output = document.getElementById('output');
    output.innerHTML = "<div>" + e.target + "</div>";

    // alert(e,clientY);
    // alert(e,clientX);
    // alert(e,offsetY);
    // alert(e,offsetX);

    alert(e.altKey);
    alert(e.ctrlKey);
    alert(e.shiftKey);
}