let shop = document.getElementById('shop');
// let x =['1', '2', '3', '4'];
let shopItem=[];
// let genShop=
shop.innerHTML=shopItem.map((x)=>{
    return `
    <div class="item">
    <img src="./img/image-1.jpg" width="200">
    <div class="details">
      <h3>m-shirt</h3>
      <p> Lorem ipsum dolor sit amet consectetur adipisicing.</p>
      <div class="price-quantity">
        <h2>$ 45</h2>
        <div class="buttons">
          <i onclick="" class="bi bi-dash-lg"></i>
          <div  id="" class="quantity">
           0
          </div>
          <i onclick="" class="bi bi-plus-lg"></i>
        </div>
      </div>
    </div>
  </div>
    `;
});