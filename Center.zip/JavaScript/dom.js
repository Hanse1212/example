// DOM : DOCUMENT OBJECT MODEL
// Tree of nodes, element created by the browser
// javascript can be used to read/write/manipulate to the DOM
// Object Oriented Representation

// console.dir(document);
// console.log(document.domain);
// console.log(document.URL);
// console.log(document.title);
// document.title = "Welcome to my Website";
// console.log(document.doctype);
// console.log(document.head);
// console.log(document.body);
// document.all[10].textContent="자바스크립트 수업";
// console.log(document.forms[0]);

// 엘리먼트 읽기
// console.log(document.getElementById('header-title'));
// 변수, 변수들어갈 수 있는 값, 저장할 수 있는 것, 숫자, 문자(string), 함수, 객체, 배열
var headerTitle = document.getElementById('header-title');
console.log(headerTitle);
headerTitle.textContent="설문조사";
headerTitle.innerText="Good job";
headerTitle.innerHTML="<h3> To do List </h3>";
headerTitle.style.borderBottom="dashed 2px #AA8B56";

//클래스 가져오기
var items = document.getElementsByClassName('list-group-item');
console.log(items);
console.log(items[1]);
items[1].textContent="Homework";
items[1].style.fontWeight="bold";
items[1].style.backgroundColor="gold";

// items.style.backgroundColor="pink"; 대신 반복문 사용 
for(var i=0; i<items.length; i++){
    items[i].style.backgroundColor="#f4f4f4";
}

var header = document.querySelector('#main-header');
header.style.borderBottom="4px solid #81C6E8";

var input = document.querySelector('input');
input.value = "Type something";

var submit = document.querySelector('input[type=submit]');
submit.value= "기록하기";

items[0].style.color="pink";

// var lastItem = document.querySelector('.list-group-item:last-child');
// lastItem.style.color="blue";

var titles = document.querySelectorAll('.title');
console.log(titles);
var odd = document.querySelectorAll('li:nth-child(odd)');
var even = document.querySelectorAll('li:nth-child(even)');

for(var i=0; i< odd.length; i++){
    odd[i].style.backgroundColor="#f4f4f4";
    even[i].style.backgroundColor="#ccc";
}

var itemList = document.querySelector('#items');
console.log(itemList);

console.log('itemList.parentNode', itemList.parentNode);
itemList.parentNode.style.backgroundColor="hotpink";

itemList.parentElement.style.backgroundColor="lightgreen";

itemList.children[1].style.backgroundColor="gold";

itemList.lastElementChild.textContent="Mango";

console.log(itemList.nextSibling);
console.log(itemList.nextElementSibling);
console.log(itemList.previousElementSibling);
itemList.previousElementSibling.style.color="#9A1663";

var newDiv = document.createElement('div');

newDiv.className="demo";
console.log(newDiv);
newDiv.id="myDiv";
console.log(newDiv);
newDiv.setAttribute('title', 'Hello Div');

var newDivText = document.createTextNode('example');

newDiv.appendChild(newDivText);

var container = document.querySelector('header', '.container');
var h1 = document. querySelector('header h1');

// container.insertBefore(newDiv, h1);
newDiv.style.fontSize="30px";