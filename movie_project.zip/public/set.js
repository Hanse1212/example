var setNum = "";
function set(a){
 setNum = a;
}

function set_select(a) {
    var txt = ['a', 'b', 'c', 'd', 'e'];
    var number = document.getElementById('set-number');
    for(var i=0; i<5; i++){
        for(var j=1; j<=5; j++){
            if(document.getElementById(a).textContent == "X"){
                return 0;
            }
            if(document.getElementById(`${txt[i]}${j}`).textContent == "X"){
                document.getElementById(`${txt[i]}${j}`).style.backgroundColor = '#red';
                continue;
            }
            document.getElementById(`${txt[i]}${j}`).style.backgroundColor = '#fff';
            document.getElementById(`${txt[i]}${j}`).style.color = '#000';
        }
    }
    number.textContent = a;
    document.getElementById(a).style.backgroundColor = 'rgb(187, 134, 255)';
    document.getElementById(a).style.color = '#fff';
    set(number.textContent);
}
function set_res(){
    var name = document.getElementById('input-name');
    if(setNum == ""){
        alert('좌석을 선택해 주세요');
    } else if(name.value == ""){
        alert('이름을 입력해 주세요');
    } else {
        alert('예약이 완료되었습니다.');
        name.value = null;
        document.getElementById(setNum).style.backgroundColor = 'red';
        document.getElementById(setNum).style.color = '#fff';
        document.getElementById(setNum).style.cursor = 'default';
        document.getElementById(setNum).textContent = "X";
    }
}
function re_set(){
    var txt = ['a', 'b', 'c', 'd', 'e'];
    for(var i=0; i<5; i++){
        for(var j=1; j<=5; j++){
            document.getElementById(`${txt[i]}${j}`).style.backgroundColor = '#fff';
            document.getElementById(`${txt[i]}${j}`).style.color = '#000';
        }
    }
}