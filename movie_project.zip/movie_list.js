var mySql = require('mysql');
var db_info = {
    host: 'localhost',
    user: 'root',
    password: 'toor',
    database: 'list'
}
module.exports = {
    init : function(){
        return mySql.createConnection(db_info);
    },
    connect : function(conn){
        conn.connect(function(err){
            if(err) console.log(err);
        })
    }
}