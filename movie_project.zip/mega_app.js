const express = require('express');
const app = express();

var db_config = require(__dirname+'/movie_list.js');
var conn = db_config.init();
db_config.connect(conn);

app.listen(1212, 'localhost',()=>{
    console.log('Server on');
})
app.set('view engine', 'ejs');
app.use(express.static('public'));

app.get('/', (req, res)=>{
    res.render('index');
})
app.get('/login', (req, res)=>{
    res.render('login');
})
app.get('/list', function(req, res){
    var sql = 'select * from movieShow';
    conn.query(sql, function(err, rows, fields){
        if(err){
            console.log('쿼리 실행 x', err);
            console.log(rows);
        } else {
            res.render('list',{list: rows});
        }
    })
})
app.get('/res', function(req, res){
    var sql = 'select * from res';
    conn.query(sql, function(err, rows, fields){
        if(err){
            console.log('쿼리 실행 x', err);
            console.log(rows);
        } else {
            res.render('reservation',{list: rows});
        }
    })
})
app.get('/ressub', function(req, res){
    var sql = 'select * from movieShow';
    conn.query(sql, function(err, rows, fields){
        if(err){
            console.log('쿼리 실행 x', err);
            console.log(rows);
        } else {
            res.render('res_sub',{list: rows});
        }
    })
})
app.use((req, res)=>{
    res.status(404).render('404');
})